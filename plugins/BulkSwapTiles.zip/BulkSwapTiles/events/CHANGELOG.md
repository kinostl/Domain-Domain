# Swap Tiles Change Log
 
## [1.1.1] - 2023-04-04

### Added
- Ability to collapse the sections of the different tiles.

## [1.1.0] - 2023-04-04
 
### Added
  16 block mode - for tiles that are stored as 16x16 in the tile sheet.
### Changed
  
- tilesheet name will now automatically change to lowercase.
- arbitrarily increased max_tiles to 50.